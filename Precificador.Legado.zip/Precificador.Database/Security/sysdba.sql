﻿CREATE USER [sysdba] FOR LOGIN [sysdba];


﻿using System;
using System.Windows.Forms;

namespace Precificador.App.Produtos
{
    public partial class FrmDetalheProduto : Form
    {
        public FrmDetalheProduto()
        {
            InitializeComponent();
        }

        private void FrmDetalheProduto_Load(object sender, EventArgs e)
        {

        }
    }
}

﻿using Precificador.Core.Entities;

namespace Precificador.Core.Interfaces
{
    public interface IColecaoRepository : IBaseRepository<ColecaoDto>
    {

    }
}
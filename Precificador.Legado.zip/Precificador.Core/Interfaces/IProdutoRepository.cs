﻿using Precificador.Core.Entities;

namespace Precificador.Core.Interfaces
{
    public interface IProdutoRepository : IBaseRepository<ProdutoDto>
    {

    }
}